from setuptools import setup

setup(name='pycrystalpay',
      version='1.0',
      description='Lib for crystalpy',
      packages=['pycrystalpay'],
      author_email='seraphineru@mail.ru',
      zip_safe=False)
