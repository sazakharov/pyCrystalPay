from setuptools import setup

setup(name='pycrystalpay',
      version='2.2.2',
      description='Lib for crystalpy.',
      packages=['pycrystalpay'],
      url="https://github.com/seraphineRU/pyCrystalPay/",
      long_description='doc - https://github.com/seraphineRU/pyCrystalPay/',
      author_email='seraphineru@mail.ru',
      zip_safe=False)
